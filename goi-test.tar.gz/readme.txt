This archive contains a minimal package for experiments with chemlambda. For the whole chemlambda repository see [0]. The author's page is Marius Buliga [1], aka "chorasimilarity". 

The archive was made in order to facilitate comparisons with the GoI Visualiser of  Koko Muroya and Steven Cheung, working under the direction of Dan Ghica [2]. See [3] (and possibly newer posts there) for context. 

[0] https://github.com/chorasimilarity/chemlambda-gui/blob/gh-pages/dynamic/README.md
[1] http://imar.ro/~mbuliga/
[2] https://koko-m.github.io/GoI-Visualiser/
[3] https://chorasimilarity.wordpress.com/2018/12/04/diagrammatic-execution-models-lambda-world-cadiz-2018-compared-with-chemlambda/

_______________________________________


LICENCE. This work is licensed under a Creative Commons Attribution 4.0 International License. 
Chemlambda is studied as Open Science. Your use of the content of this archive, or any other part of chemlambda, is a form of validation. The results of your use, like your comments, programs, experiments, critic, articles, animations, etc, should be publicly available, but this is your choice to make. Any time when such a derivative work is made public, it should contain means for the readers to be able to discover your sources, in order for them to be able to validate your work. 

_______________________________________


HOW TO USE. In terminal, 

bash quiner_shuffle.sh

# a list of the files from the "mol" folder appears. All are files  .mol. Choose one of them by typing the full name, for example

goi.mol 

# the script quiner_shuffle.sh calls an awk script from the awk folder and the output is wrapped (by using files from the wrap folder) into a file.html. For the example considered, 

ls *.html

#will show you 

goi.html

#now use a browser, for example

firefox goi.html &

# and look at the animation produced, which depicts precisely the result of the random reduction algorithm of chemlambda, applied to the file goi.mol. Because the reduction is random, a new reduction may be different than the one you just obtained. If you want to keep a reduction (i.e. a file. html) then 

mv goi.html html

# i.e. save it in the html folder. 

# The html folder already contains several reductions. The folder mp4 contains mp4 videos of these reductions (made with recordmydesktop and trimmed or sped up with ffmpeg). The folder gif contain animated gifs of the same, at faster speed. 
